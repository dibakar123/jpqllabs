package com.jpaproj.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NamedQuery;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.jpaproj.entity.AuthorEntity;

public class MyDaoImpl implements MyDao {

	EntityManagerFactory entityManagerFactory;
	EntityManager entityManager;
	
	public MyDaoImpl() {
		 entityManagerFactory = JPAUtil.getEntityManagerFactory();
		 entityManager = entityManagerFactory.createEntityManager();
	}
public void query1() {
		Query query = entityManager.createQuery("select a from AuthorEntity a"); // JPQL Query
		List<AuthorEntity> list = query.getResultList();
		for( AuthorEntity entity : list) {
			System.out.println(entity);
		}
	}
	
public void query2() {
		TypedQuery<AuthorEntity> query = entityManager.createQuery("select a from AuthorEntity a" , AuthorEntity.class); // JPQL Query
		List<AuthorEntity> list = query.getResultList();
		for( AuthorEntity entity : list) {
			System.out.println(entity);
		}
	}
	
public void query3() {
TypedQuery<AuthorEntity> query = entityManager.createQuery("select a from AuthorEntity a where a.middleName=:para" , AuthorEntity.class); // JPQL Query
query.setParameter("para", "cc");
List<AuthorEntity> list = query.getResultList();
		for( AuthorEntity entity : list) {
			System.out.println(entity);
		}
	}

public void query4() {
TypedQuery<AuthorEntity> query = entityManager.createQuery("select a from AuthorEntity a where a.middleName=?1" , AuthorEntity.class); // JPQL Query
query.setParameter(1, "cc");
List<AuthorEntity> list = query.getResultList();
		for( AuthorEntity entity : list) {
			System.out.println(entity);
		}
	}

public void query5() {
Query query = entityManager.createNamedQuery("findAuthor");
List<AuthorEntity> list = query.getResultList();
		for( AuthorEntity entity : list) {
			System.out.println(entity);
		}
	}

public void query6() {
	TypedQuery<AuthorEntity> query = entityManager.createQuery("select a from AuthorEntity a where a.authorId=:id" , AuthorEntity.class); // JPQL Query
	query.setParameter("id", 200);
	AuthorEntity entity = query.getSingleResult();
	System.out.println(entity);
	
}

public void query7() {
	String st = "delete from AuthorEntity where authorId=100";
	entityManager.getTransaction().begin();
	Query query = entityManager.createQuery(st);
	int n = query.executeUpdate();
	System.out.println(n);
	entityManager.getTransaction().commit();
}

}








