package com.jpaproj.dao;

public interface MyDao {
    public void query1();
    public void query2();
    public void query3();
    public void query4();
    public void query5();
    public void query6();
    public void query7();
}
