package com.jpaproj;

import com.jpaproj.dao.MyDao;
import com.jpaproj.dao.MyDaoImpl;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        MyDao dao = new MyDaoImpl();
       // dao.query1();
        //dao.query2();
       // dao.query3();
        //dao.query4();
        //dao.query5();
        //dao.query6();
        dao.query7();
    }
}
